$(document).ready(function () {
    $(".expand-collapse-row").on("click", function () {
        if ($(this).find("i").hasClass("icofont-circled-down")){
            $(".message-body").removeClass("expand");
        }
        else{
            $(".message-body").addClass("expand"); 
        }
        $(".expand-collapse-row i").toggleClass("icofont-circled-up icofont-circled-down");
    })
    $(".expand-data").on("click", function () {
        $(this).parents("tr").find(".message-body").toggleClass("expand");
    })
    $(".main-navigation li").on("click", function () {
        $(".main-navigation li").removeClass("has-class");
        $(this).addClass("has-class");
    })
    $("#accordion .panel-title").on("click", function () {
        $(this).find("i.icon").toggleClass("icon-plus-sign icon-minus-sign");
    })
    $(".select2-dd").select2();
});